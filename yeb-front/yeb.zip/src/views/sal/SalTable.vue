<template>
    <div>
        工资表
    </div>
</template>

<script>
    export default {
        name: "SalTable"
    }
</script>

<style scoped>

</style>