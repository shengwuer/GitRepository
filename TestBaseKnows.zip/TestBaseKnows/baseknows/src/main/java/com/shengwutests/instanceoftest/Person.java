package com.shengwutests.instanceoftest;
    /**
 *  TODO : 测试instanceof
 * 
 * @Created   : by 湖南爱豆  
 * @Date      ： 2021/4/8 17:29
 * @Author    : 谢迪 
 */
public class Person {

//    5、obj 为 class 类的直接或间接子类
//　　我们新建一个父类 Person.class，然后在创建它的一个子类 Man.class

}